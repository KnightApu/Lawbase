package com.adhocmaster.login;


public interface LoginProvider {
    
    LoginAdapter getLoginAdapter();

}
