package com.adhocmaster.login;


public interface LoginAdapter {
    

}
